/**
 * Dnyandeep Coaching Classes - Main JavaScript File
 */

document.addEventListener('DOMContentLoaded', () => {
    // ==========================================================================
    // 1. Loading Screen
    // ==========================================================================
    const loader = document.getElementById('loader');
    if (loader) {
        window.addEventListener('load', () => {
            setTimeout(() => {
                loader.style.opacity = '0';
                setTimeout(() => {
                    loader.style.display = 'none';
                }, 500); // Wait for transition to complete
            }, 300); // Brief delay for visual satisfaction
        });
    }

    // ==========================================================================
    // 2. Sticky Navbar and Back-To-Top Button
    // ==========================================================================
    const header = document.querySelector('header');
    const toTopBtn = document.getElementById('btnToTop');
    
    const handleScroll = () => {
        const scrollPosition = window.scrollY;
        
        // Sticky Header
        if (header) {
            if (scrollPosition > 120) {
                header.classList.add('sticky');
            } else {
                header.classList.remove('sticky');
            }
        }
        
        // Back to top Button
        if (toTopBtn) {
            if (scrollPosition > 400) {
                toTopBtn.classList.add('active');
            } else {
                toTopBtn.classList.remove('active');
            }
        }
    };
    
    window.addEventListener('scroll', handleScroll);
    
    // Smooth Scroll to Top
    if (toTopBtn) {
        toTopBtn.addEventListener('click', (e) => {
            e.preventDefault();
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });
    }

    // ==========================================================================
    // 3. Mobile Navigation Menu Toggle
    // ==========================================================================
    const hamburger = document.getElementById('hamburger');
    const navMenu = document.getElementById('navMenu');
    const navLinks = document.querySelectorAll('.nav-link');
    
    if (hamburger && navMenu) {
        hamburger.addEventListener('click', () => {
            hamburger.classList.toggle('active');
            navMenu.classList.toggle('active');
        });
        
        // Close menu on link click
        navLinks.forEach(link => {
            link.addEventListener('click', () => {
                hamburger.classList.remove('active');
                navMenu.classList.remove('active');
            });
        });
    }

    // ==========================================================================
    // 4. Dismissible Admissions Announcement Banner
    // ==========================================================================
    const announcementBar = document.getElementById('announcementBar');
    const closeAnnouncement = document.getElementById('closeAnnouncement');
    
    if (announcementBar && closeAnnouncement) {
        closeAnnouncement.addEventListener('click', () => {
            announcementBar.style.height = '0';
            announcementBar.style.padding = '0';
            announcementBar.style.overflow = 'hidden';
            announcementBar.style.border = 'none';
        });
    }

    // ==========================================================================
    // 5. Scroll Reveal Animations (Intersection Observer)
    // ==========================================================================
    const revealElements = document.querySelectorAll('.reveal');
    
    const revealOnScroll = () => {
        const triggerBottom = window.innerHeight * 0.85;
        
        revealElements.forEach(element => {
            const elementTop = element.getBoundingClientRect().top;
            
            if (elementTop < triggerBottom) {
                element.classList.add('active');
            }
        });
    };
    
    // Run once initially to load any above-the-fold reveals
    setTimeout(revealOnScroll, 100);
    window.addEventListener('scroll', revealOnScroll);

    // ==========================================================================
    // 6. Testimonial Slider / Carousel
    // ==========================================================================
    const sliderTrack = document.getElementById('sliderTrack');
    const slides = document.querySelectorAll('.testimonial-slide');
    const dotsContainer = document.getElementById('sliderDots');
    
    if (sliderTrack && slides.length > 0 && dotsContainer) {
        let currentSlideIndex = 0;
        const slideCount = slides.length;
        let slideInterval;
        
        // Create Dots dynamically
        slides.forEach((_, index) => {
            const dot = document.createElement('div');
            dot.classList.add('slider-dot');
            if (index === 0) dot.classList.add('active');
            dot.addEventListener('click', () => {
                goToSlide(index);
                resetInterval();
            });
            dotsContainer.appendChild(dot);
        });
        
        const dots = document.querySelectorAll('.slider-dot');
        
        const goToSlide = (index) => {
            currentSlideIndex = index;
            sliderTrack.style.transform = `translateX(-${currentSlideIndex * 100}%)`;
            
            // Update dots
            dots.forEach(dot => dot.classList.remove('active'));
            if (dots[currentSlideIndex]) {
                dots[currentSlideIndex].classList.add('active');
            }
        };
        
        const nextSlide = () => {
            let nextIndex = currentSlideIndex + 1;
            if (nextIndex >= slideCount) nextIndex = 0;
            goToSlide(nextIndex);
        };
        
        const startInterval = () => {
            slideInterval = setInterval(nextSlide, 5000); // Auto-advance every 5 seconds
        };
        
        const resetInterval = () => {
            clearInterval(slideInterval);
            startInterval();
        };
        
        // Start slider
        startInterval();
        
        // Swipe / Drag support for tablets/mobile (basic)
        let startX = 0;
        let isDragging = false;
        
        sliderTrack.addEventListener('touchstart', (e) => {
            startX = e.touches[0].clientX;
            isDragging = true;
            clearInterval(slideInterval);
        }, { passive: true });
        
        sliderTrack.addEventListener('touchend', (e) => {
            if (!isDragging) return;
            const endX = e.changedTouches[0].clientX;
            const diffX = startX - endX;
            
            if (Math.abs(diffX) > 50) { // minimum threshold for swipe
                if (diffX > 0) {
                    // Swiped left -> next slide
                    let nextIndex = currentSlideIndex + 1;
                    if (nextIndex < slideCount) goToSlide(nextIndex);
                } else {
                    // Swiped right -> prev slide
                    let prevIndex = currentSlideIndex - 1;
                    if (prevIndex >= 0) goToSlide(prevIndex);
                }
            }
            isDragging = false;
            startInterval();
        });
    }

    // ==========================================================================
    // 7. Stat Counters Animation
    // ==========================================================================
    const counterElements = document.querySelectorAll('.stat-number');
    
    if (counterElements.length > 0) {
        const counterObserver = new IntersectionObserver((entries, observer) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    const targetElement = entry.target;
                    const targetValueStr = targetElement.getAttribute('data-target');
                    // Parse target number (handling +, %, etc)
                    const targetValue = parseInt(targetValueStr.replace(/[^0-9]/g, ''));
                    const isPercentage = targetValueStr.includes('%');
                    const isPlus = targetValueStr.includes('+');
                    
                    let startValue = 0;
                    const duration = 2000; // 2 seconds duration
                    const startTime = performance.now();
                    
                    const animateCounter = (currentTime) => {
                        const elapsedTime = currentTime - startTime;
                        const progress = Math.min(elapsedTime / duration, 1);
                        
                        // Ease out quad
                        const easeProgress = progress * (2 - progress);
                        const currentValue = Math.floor(easeProgress * targetValue);
                        
                        targetElement.textContent = currentValue + (isPercentage ? '%' : '') + (isPlus ? '+' : '');
                        
                        if (progress < 1) {
                            requestAnimationFrame(animateCounter);
                        } else {
                            targetElement.textContent = targetValueStr; // set final raw format
                        }
                    };
                    
                    requestAnimationFrame(animateCounter);
                    observer.unobserve(targetElement); // Animate only once
                }
            });
        }, { threshold: 0.5 });
        
        counterElements.forEach(counter => {
            counterObserver.observe(counter);
        });
    }

    // ==========================================================================
    // 8. FAQ Accordion behavior
    // ==========================================================================
    const faqQuestions = document.querySelectorAll('.faq-question');
    
    faqQuestions.forEach(question => {
        question.addEventListener('click', () => {
            const faqItem = question.parentElement;
            const isActive = faqItem.classList.contains('active');
            
            // Close all items
            document.querySelectorAll('.faq-item').forEach(item => {
                item.classList.remove('active');
                const answer = item.querySelector('.faq-answer');
                if (answer) answer.style.maxHeight = null;
            });
            
            // Toggle clicked item
            if (!isActive) {
                faqItem.classList.add('active');
                const answer = faqItem.querySelector('.faq-answer');
                if (answer) {
                    answer.style.maxHeight = answer.scrollHeight + "px";
                }
            }
        });
    });

    // ==========================================================================
    // 9. Simple Contact Form Submission
    // ==========================================================================
    const contactForm = document.getElementById('customContactForm');
    if (contactForm) {
        contactForm.addEventListener('submit', (e) => {
            e.preventDefault();
            
            // Get values
            const name = document.getElementById('formName').value;
            const phone = document.getElementById('formPhone').value;
            const course = document.getElementById('formCourse').value;
            const message = document.getElementById('formMessage').value;
            
            // Create a WhatsApp text payload
            const text = `Hi, my name is ${name}. Phone: ${phone}. I am interested in ${course}. Message: ${message}`;
            const encodedText = encodeURIComponent(text);
            
            // Redirect to WhatsApp
            window.open(`https://wa.me/918329931123?text=${encodedText}`, '_blank');
        });
    }
});
